###
You can modify the path of mvs camera take photos log in th utils/cfgs.py

###
Demo as fallow.

***
        import cv2
        import time
        
        from dfk_get_photo_arr import DfsGetPhoto
        
        
        if __name__ == "__main__":
            # # Get one image.
            # mvsGetPhoto = MvsGetPhoto()
            mvsGetPhoto.camera_init()
            # img0 = mvsGetPhoto.get_photo(sn0)
            # img1 = mvsGetPhoto.get_photo(sn1)
            # img2 = mvsGetPhoto.get_photo(sn2)
            # mvsGetPhoto.destroy_handle()
            # mvsGetPhoto.destroy_thread()
        
            # With thread.
            mvsGetPhoto = MvsGetPhoto(thread=True)
            mvsGetPhoto.camera_init()
            images = mvsGetPhoto.thread_get_photo([sn1, sn2, ...])
            or serials = mvsGetPhoto.serials
               images = mvsGetPhoto.thread_get_photo(serials)
            mvsGetPhoto.destroy_handle()
            mvsGetPhoto.destroy_thread()