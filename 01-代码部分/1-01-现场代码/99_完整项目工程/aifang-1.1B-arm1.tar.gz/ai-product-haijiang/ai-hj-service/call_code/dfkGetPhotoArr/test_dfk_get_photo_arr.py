# -- coding: utf-8 --

import cv2
import time

from dfk_get_photo_arr import DfsGetPhoto
import os


if __name__ == "__main__":
    # dfsGetPhoto = DfsGetPhoto(driver_mode='USB')
    dfsGetPhoto = DfsGetPhoto(driver_mode='GigE')
    devices = dfsGetPhoto.enumSerials
    print(devices)
    # dfsGetPhoto.camera_init(['38914555'], framerate='24/1')  # ['13914456', '35024021']
    dfsGetPhoto.camera_init(manu_set_camera=True)  #
    # dfsGetPhoto.camera_init(manu_set_camera=False)  #

    CP = [
    {
        'sn': '13914456',
        'param': {
            "Trigger Debouncer": 560000.0,
            "Trigger Delay (us)": 800.0,
            "Trigger Mode": 'On',
            # "Trigger Activation": "RisingEdge"
            "Trigger Activation": "FallingEdge",
            "CD_busy": False,  # CD参数必须要以CD_开始
            "Whitebalance Auto": 'Off',
            "Whitebalance Mode": "WhiteBalanceMode_Temperature",
            "Whitebalance Temperature": 7200,
            # "Whitebalance Green": 64,
            # "Whitebalance Blue": 115,
            # "Whitebalance Red": 125
            "Gain Auto": 'Off',
            "Gain": 2.10,
            "Exposure Auto": 'Off',
            "Exposure": 28000,
            "Gamma": 0.41,
            "IMXLowLatencyTriggerMode": True
            }
    },
    {
        'sn': '35024021',
        'param': {
            "Trigger Debouncer": 560000.0,
            "Trigger Delay (us)": 800.0,
            "Trigger Mode": 'On',
            # "Trigger Activation": "RisingEdge"
            "Trigger Activation": "FallingEdge",
            "CD_busy": False,  # CD参数必须要以CD_开始
            "Whitebalance Auto": 'Off',
            "Whitebalance Mode": "WhiteBalanceMode_Temperature",
            "Whitebalance Temperature": 7200,
            # "Whitebalance Green": 64,
            # "Whitebalance Blue": 115,
            # "Whitebalance Red": 125
            "Gain Auto": 'Off',
            "Gain": 2.10,
            "Exposure Auto": 'Off',
            "Exposure": 28000,
            "Gamma": 0.41,
            "IMXLowLatencyTriggerMode": True
        }
    }
    ]
    for cp in CP:
        dfsGetPhoto.setCameraParamManu(cp)

    n = 0
    for i in range(100):
        time.sleep(0.0)
        start = time.time()
        # images = dfsGetPhoto.thread_get_photo(['38914555'])
        images = dfsGetPhoto.thread_get_photo(devices)
        # for j, sn in enumerate(devices):
        #     path = f"/mnt/data/image/{sn}_{i}.jpg"
        #     cv2.imwrite(path, images[j])
        # if not os.path.exists("/mnt/data/data/dfk"):
        #     os.makedirs("/mnt/data/data/dfk")
        # cv2.imwrite(f"/mnt/data/data/dfk/img_{n}.jpg", images[0])
        print(f"time loss: {time.time()-start}")
        # print(f"len: {len(images)}")
        n+=1
    dfsGetPhoto.destroy_handle()
    dfsGetPhoto.destroy_thread()

    # dfsGetPhoto = None
    # dfsGetPhoto = DfsGetPhoto()
    # devices = dfsGetPhoto.enumSerials
    # print(devices)
    # dfsGetPhoto.camera_init()
    # for i in range(5):
    #     time.sleep(2)
    #     start = time.time()
    #     images = dfsGetPhoto.thread_get_photo(devices)
    #     # for j, sn in enumerate(devices):
    #     #     path = f"/mnt/data/image/{sn}_{i}.jpg"
    #     #     cv2.imwrite(path, images[j])
    #     print(f"time loss: {time.time()-start}")
    #     print(f"len: {len(images)}")
    # dfsGetPhoto.destroy_handle()
    # dfsGetPhoto.destroy_thread()
    # # a = "a"
    # # assert isinstance(a, int), 'a wrong.'
    # # while 1:
    # #     pass
    #
    # dfsGetPhoto = DfsGetPhoto()
    # devices = dfsGetPhoto.enumSerials
    # print(devices)
    # dfsGetPhoto.camera_init()
    # for i in range(5):
    #     time.sleep(2)
    #     start = time.time()
    #     images = dfsGetPhoto.thread_get_photo(devices)
    #     # for j, sn in enumerate(devices):
    #     #     path = f"/mnt/data/image/{sn}_{i}.jpg"
    #     #     cv2.imwrite(path, images[j])
    #     print(f"time loss: {time.time()-start}")
    #     print(f"len: {len(images)}")
    # dfsGetPhoto.destroy_handle()
    # dfsGetPhoto.destroy_thread()
