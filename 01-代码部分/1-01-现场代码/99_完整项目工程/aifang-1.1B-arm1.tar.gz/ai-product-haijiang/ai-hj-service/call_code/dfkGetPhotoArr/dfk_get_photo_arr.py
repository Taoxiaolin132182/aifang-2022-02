# -- coding: utf-8 --

import os
import sys
import copy
import cv2
import time
import signal

from multiprocessing.dummy import Pool as ThreadPool

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dfkGetPhotoArr.lib import TIS
from dfkGetPhotoArr.lib.logger import get_logger
from dfkGetPhotoArr.utils.cfgs import *


class CustomData:
    ''' Example class for user data passed to the on new image callback function
    '''

    def __init__(self, newImageReceived, image):
        self.newImageReceived = newImageReceived
        self.image = image
        self.busy = False


def on_new_image(tis, userdata):
    '''
    Callback function, which will be called by the TIS class
    :param tis: the camera TIS class, that calls this callback
    :param userdata: This is a class with user data, filled by this call.
    :return:
    '''
    # Avoid being called, while the callback is busy
    if userdata.busy is True:
        return

    userdata.busy = True
    userdata.newImageReceived = True
    userdata.image = tis.Get_image()
    userdata.busy = False


class DfsGetPhoto():
    """
    Take photos from DFS camera.
    """

    def __init__(self, driver_mode='GigE', signal_mode=False):
        """
        :param driver_mode: The category of camera driver. 'GigE' or 'USB'.
                            Parameter from ['On', 'Off'] when use 'GigE' and
                            [True, False] when use 'USB'.
        :param signal_mode: Deal with launched application for resource release
                            when get signal of exception. Like kill pid, Ctrl-C.
                            Signal only works in main thread.
        """
        assert driver_mode in ['GigE', 'USB'], f'No {driver_mode} camera.'
        self.driver_mode = driver_mode
        self.logger = get_logger("DFS_take_photo")
        self._camera_enum()
        if signal_mode:
            self._call_signal()

    def _exception_handler(self, signalnum, frame):
        """
        Deal with launched application for resource release.
        :param signalnum: The signal num.
        :param frame: Frame of process.
        :return:-
        """
        self.destroy_handle()
        self.destroy_thread()
        self.logger.debug(f"Signal Receive Signalnum: {signalnum}, "
                          f"Frame: {frame}. "
                          f"Deal with launched application for resource release.")
        exit(0)

    def _call_signal(self, ):
        """
        Track signal of exception.
            NUM     NAME	    EXPLANATION
            1       SIGHUP      To terminate control terminal or process. (term)
            2		SIGINT		'Ctrl-c 'from keyboard. (term)
            3       SIGQUIT     A signal to the process from Control terminal,
                                keyboard generated exit (CTRL-\). (dump)
            5       SIGTRAP     break off by debug. (dump)
            9		SIGKILL		Force-kill process. (term)
                                This signal process cannot be ignored.
                                It is killed directly at the system level,
                                can't listen in Python.
            14		SIGALRM		alarm signal. (term)
            15		SIGTERM		'kill sigterm pid' from terminal. (term)
        :return:-
        """
        signal.signal(signal.SIGHUP, self._exception_handler)
        signal.signal(signal.SIGINT, self._exception_handler)
        signal.signal(signal.SIGTERM, self._exception_handler)
        signal.signal(signal.SIGTRAP, self._exception_handler)
        signal.signal(signal.SIGQUIT, self._exception_handler)

    def _camera_enum(self, ):
        """
        Enumerate devices get the found serial num.
        :return:-
        """
        # ch:枚举设备 | en:Enum device
        self.camera_sdn, self.camera_dsn = TIS.get_serials()
        self.device = len(self.camera_sdn.keys())
        self.logger.debug("Find  device: [%d]" % self.device)

    def camera_init(self,
                    sn_list=None,
                    thread=True,
                    img_format='BGR',
                    live_video=False,
                    framerate='24/1',
                    time_out=1000,
                    b_sleep=1,
                    manu_set_camera=False):
        """
        Camera initialize.
        :param sn_list: List of serial [sel1, sel2 ...], Default all if None.
        :param thread: If you want use multiprocess.
        :param img_format: The picture format that you want to get, BGR or RGB.
        :param live_video: Mode of video convert  x image sink.
        :param time_out: Timeout for get frame from camera, ms.
        :param b_sleep: Sleep time for buffer frame after camera initialize, s.
        :param manu_set_camera: set camera by function .
        """

        if thread:
            try:
                self.destroy_thread()
            except Exception as e:
                pass
            self.pool = ThreadPool(
                self.device)  # 创建n个容量的线程池并发执行
            self.logger.debug(f"Thread has been created successfully.")

        assert img_format in ['rggb', 'rggb12p', 'rggb16', 'RGB', 'BGR'], \
            f'Nonsupport this format: {img_format}'
        self.img_format = img_format
        # self.framerate = framerate
        self.time_out = time_out
        self.b_sleep = b_sleep
        self._camera_enum()
        if sn_list and self.device != len(sn_list):
            self.logger.warning(
                f"Find {self.device} device but get {len(sn_list)}.")
        self.init_sn = self.camera_sdn.keys() if not sn_list else sn_list
        try:
            initeds = copy.deepcopy(list(self.ParamDict.keys()))
            if len(initeds) > 0:
                self.logger.warning(f"Handles exist, they will be destroyed.")
                # self.destroy_handle(list(set(self.init_sn) & set(initeds)))
                self.destroy_handle(initeds)
        except Exception as e:
            self.logger.debug(f"No handle exist, it will be created.")

        self.ParamDict = dict()
        for ii, sn in enumerate(self.init_sn):
            assert sn in self.camera_sdn.keys(), \
                f'{sn} not exist in {list(self.camera_sdn.keys())}'
            self.ParamDict[sn] = dict()

            CD = CustomData(False, None)
            Tis = TIS.TIS()

            # Selecting a device, video format and frame rate.
            try:
                Tis.selectDevice(sn, format=self.img_format, livevideo=live_video, rate=framerate)
            except Exception as e:
                self.logger.error(f'One error occur with {e}, When select device')
                raise Exception(f'One error occur with {e}, When select device')

            # Add callback function.
            Tis.Set_Image_Callback(on_new_image, CD)

            # Use this line for GigE cameras
            if self.driver_mode == 'GigE':
                Tis.Set_Property("Trigger Mode", "Off")  # Use this line for GigE cameras
            elif self.driver_mode == 'USB':
                Tis.Set_Property("Trigger Mode", False)  # Use this line for USB cameras
            # Avoid, that we handle image, while we are in the pipeline start phse
            CD.busy = True
            # Start the pipeline
            try:
                Tis.Start_pipeline()
            except Exception as e:
                self.logger.error(f'One error occur with {e}, When start pipeline')
                raise Exception(f'One error occur with {e}, When start pipeline')

            # Use this line for GigE cameras
            # Shut off white balance and set white balance.
            # Shut off Gain Auto and set Gain.
            # Shut off Exposure Auto and set Exposure and Gamma.
            if not manu_set_camera:
                self.setDfsCameraParam(sn, Tis, CD)

            self.ParamDict[sn] = {'tis': Tis, 'cd': CD}
            self.logger.debug(f"Serial {sn} successfully initialized.")

            # Clean cached images
            n = 0
            while True:
                try:
                    self.get_photo(sn, trigger=False)
                    n += 1
                except:
                    break
            self.logger.debug(f"Cleaned cached images: {n}")

    def get_photo(self, deSn, tries=100, trigger=True):
        """
        :param deSn: The device of camera.
        :param tries: Number of repeated reads. Default 10 times.
        :param trigger: Whether trigger camera to take photos.
        :return:
        """
        assert deSn in self.camera_sdn.keys(), f'No this camera serial {deSn}'
        assert isinstance(deSn, str) and deSn in self.ParamDict.keys(), \
            f'{deSn} device has not been initialized.'

        # Send a software trigger
        if trigger:
            self.ParamDict[deSn]['tis'].Set_Property("Software Trigger", 1)

        # Wait for a new image. Use 10 tries.
        while self.ParamDict[deSn]['cd'].newImageReceived is False and tries > 0:
            time.sleep(0.01)
            tries -= 1

        # Check, whether there is a new image and handle it.
        if self.ParamDict[deSn]['cd'].newImageReceived is True:
            self.ParamDict[deSn]['cd'].newImageReceived = False
            # img = np.ascontiguousarray(self.ParamDict[deSn]['cd'].image[:, :, :3])
            # img = cv2.cvtColor(self.ParamDict[deSn]['cd'].image[:, :, :3], cv2.COLOR_BayerBG2RGB)
            # img = cv2.cvtColor(self.ParamDict[deSn]['cd'].image[:, :, :3], cv2.COLOR_BayerGR2RGB)
            img = self.ParamDict[deSn]['cd'].image[:, :, :3]

            # self.logger.info(
            #     f"Serial: {deSn} Shape: {img.shape}")

            return {'sn': deSn, 'img': img}
        else:
            self.logger.error(f"{deSn}: No image received.")
            raise Exception(f"{deSn}: No image received.")

    def thread_get_photo(self, devices):
        """
        Get the photo with multithreading.
        :param devices: The list about connection device, type list.
        """
        start = time.time()
        # self.logger.info(f'Call time: {start}')
        assert isinstance(devices, list), 'Devices must be list.'
        PR = {x['sn']: x['img'] for x in self.pool.map(self.get_photo, devices)}
        back = time.time()
        # self.logger.info(f'Return time: {back} time loss: {back-start}')
        return [PR[sn] for sn in devices]

    def destroy_handle(self, deSns=None):
        """
        Destroy the handle. Not must be executed.
        The camera will lost connection for minutes
        if this function not be executed after grab images.
        :param deNum: The list about connection device or None.
                      Destroy all handle when deNums is None.
        """
        try:
            deSns = copy.deepcopy(list(self.ParamDict.keys())) if not deSns else deSns
        except Exception as e:
            self.logger.error(f'Confirm the camera initialised, {e}')
            raise Exception(f'Confirm the camera initialised, {e}')
        for i, deSN in enumerate(deSns):
            self.ParamDict[deSN]['tis'].Stop_pipeline()

            del self.ParamDict[deSN]
            self.logger.debug(
                f"Serial {deSN} handle has been destroyed successfully.")

    def destroy_thread(self):
        """
        Destroy the thread.
        """
        self.pool.close()  # 关闭线程池，不再接受新的线程
        self.pool.join()  # 主线程阻塞等待子线程的退出
        self.logger.debug(f"Thread has been closed successfully.")

    @property
    def enumSerials(self):
        """
        :return: The serial num of serials which connected. (enumerated)
        """
        try:
            enumserials = copy.deepcopy(list(self.camera_sdn.keys()))
        except Exception as e:
            raise Exception(f'{e} Confirm camera_enum has not been called.')
        return enumserials

    @property
    def initSerials(self):
        """
        :return: The serial num of serials which initialized.
        """
        try:
            initserials = copy.deepcopy(list(self.ParamDict.keys()))
        except Exception as e:
            raise Exception(f'{e} No camera has been initialized.')
        return initserials

    def getPositionSN(self):
        pass

    def getCameraonfig(self):
        """
        Get common param.
        :return:
        """
        pass

    def getExposureByParamsMark(self, cameraParamMark):
        """
        Get param of exposure and white balance.
        :return:
        """
        pass

    def setTisParameter(self, key, value, Tis):
        """
        :param Tis:
        :param CD:
        :return:
        """
        Tis.Set_Property(key, value)
        set_value = Tis.Get_Property(key).value
        assert set_value == value, f'{key} set {value} but real {set_value}'

    def setCDParameter(self, key, value, CD):
        """
        :param key:
        :param value:
        :param CD:
        :return:
        """
        exec(f"CD.{key} = {value}")

    def setDfsCameraParam(self, sn, Tis, CD):
        """
        :param sn:
        :param Tis:
        :param CD:
        :return:
        """
        camParams = eval(f"{CAMERA_SAVE_IMAGE[sn]}_CAMERA_PARAMETER")
        for key, value in camParams.items():
            if 'CD' not in key:
                self.setTisParameter(key, value, Tis)
            else:
                self.setCDParameter(key[3:], value, CD)

    def setCameraParamManu(self, CP):
        """
        :param camParams: {'sn': num
                           'param': }
        :param Tis:
        :param CD:
        :return:
        """
        assert hasattr(self, 'ParamDict'), f"Do camera init before ser param."
        assert isinstance(CP, dict), f"CP must be dict rather than {type(CP)}"
        assert CP['sn'] in self.ParamDict.keys(), f"camera {CP['sn']} not exist"
        CP['sn'] = str(CP['sn']) if not isinstance(CP['sn'], str) else CP['sn']
        for key, value in CP['param'].items():
            if 'CD' not in key:
                self.setTisParameter(key, value, self.ParamDict[CP['sn']]['tis'])
            else:
                self.setCDParameter(key[3:], value, self.ParamDict[CP['sn']]['cd'])


"""
if __name__ == "__main__":
    # Get one image.
    mvsGetPhoto = MvsGetPhoto()
    
    # camera init two ways.
    1. set camera from cfg
    mvsGetPhoto.camera_init()  
    2. set camera manual
    mvsGetPhoto.camera_init(manu_set_camera=True)
    dfsGetPhoto.setCameraParamManu(CP)  
        
    img0 = mvsGetPhoto.get_photo(sn0)
    img1 = mvsGetPhoto.get_photo(sn1)
    img2 = mvsGetPhoto.get_photo(sn2)
    mvsGetPhoto.destroy_handle()
    mvsGetPhoto.destroy_thread()



    # With thread.
    mvsGetPhoto = MvsGetPhoto(thread=True)
    mvsGetPhoto.camera_init()
    images = mvsGetPhoto.thread_get_photo([sn1, sn2, ...])
    or serials = mvsGetPhoto.serials
       images = mvsGetPhoto.thread_get_photo(serials)
    mvsGetPhoto.destroy_handle()
    mvsGetPhoto.destroy_thread()
"""
