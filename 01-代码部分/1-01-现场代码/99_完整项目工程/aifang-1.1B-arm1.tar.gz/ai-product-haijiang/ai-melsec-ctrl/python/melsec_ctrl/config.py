﻿import os
import sys

#-------------------------------------------------------------------------------------------------
#！！参数在此配置！！

#是否本机调试
DEBUG_MODE = False

## 输出目录
#OUTPUT_DIR = os.path.join("D:\\opt\\logs" if DEBUG_MODE else "/opt/logs", "ComparePic") #sys.path[0] 
#try:
#    if not os.path.exists(OUTPUT_DIR): os.makedirs(OUTPUT_DIR)
#except Exception as e:
#    print("create %s failed (%s)" % (OUTPUT_DIR, str(e)))

#-------------------------------------------------------------------------------------------------
